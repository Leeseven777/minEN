ymaps.ready(init);


 let geoobjs = [];

var myMap, krasnodar;
   function init(){

       // Создание карты.
       myMap = new ymaps.Map("map", {
           center: [64.425674, 83.780301],
           zoom: 3
       });
   }


   let wasClicked = false;
   function showRegion() {
     if (!wasClicked) {
       wasClicked = true;
       krasnodar = ymaps.geoQuery(ymaps.regions.load("RU", {
          lang: "ru"
      })).search('properties.hintContent = "Краснодарский край"').setOptions({
          fillOpacity: '0.4',
          fillColor: '#136FC9',
          strokeColor: '#000DFF'
      });
      krasnodar.addToMap(myMap);
      myMap.setZoom(7);
      myMap.panTo([45.035470, 38.975313], {
        flying: 1
      });
      makeMarkers();
     }
   }

   function makeMarkers() {
       geoobjs = new ymaps.Placemark([climat[0].latitude, climat[0].longitude], {},
      {
        // узнать posibility
        preset: getPresetByPosibility(0.5)
      });
      geoobjs.events.add("mouseenter", function (e) {
        // узнать
      					geoobjs.options.set('preset', getPresetByPosibility_hover(0.5));
                // узнать name
                geoobjs.properties.set('iconContent', 'Краснодарский край');
      				}, geoobjs);
      geoobjs.events.add("mouseleave", function (e) {
                	geoobjs.options.set('preset', getPresetByPosibility(0.5));
                  geoobjs.properties.set('iconContent', null);
              	}, geoobjs);
     geoobjs.events.add("click", function (e) {
                fillPop('Краснодарский край', 'ТЭК Курттранс');
                showPop();
                }, geoobjs);

      myMap.geoObjects.add(geoobjs);
   }


   function getPresetByPosibility(posibility) {
     if (posibility < 0.33) {
       return 'islands#redDotIcon';
     }
     else if (posibility < 0.66) {
       return 'islands#yellowDotIcon';
     }
     else {
       return	'islands#greenDotIcon'
     }
   }

   function getPresetByPosibility_hover(posibility) {
     if (posibility < 0.33) {
       return 'islands#redStretchyIcon';
     }
     else if (posibility < 0.66) {
       return 'islands#yellowStretchyIcon';
     }
     else {
       return	'islands#greenStretchyIcon';
     }
   }
