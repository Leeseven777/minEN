
$(function(){
  let options = "<option value='all' selected>Год</option>";
  for (var i = 19; i < 25; i++) {
    options+="<option value="+i+">20"+i+"</option>";
  }
  $('select#yearselect').html(options);

  countTrims();

});

function countTrims() {
  console.log('here');
  let trims = $('.trims');
  console.log(trims);
  let count1 = 0, count2 = 0, count3 = 0, count4 = 0;

  reasons.forEach((r, i) => {
    if (r.Trimestr == 1) {
      count1++;
    } else if (r.Trimestr == 2) {
      count2++;
    } else if (r.Trimestr == 3) {
      count3++;
    } else if (r.Trimestr == 4) {
      count4++;
    }
  });

  console.log(count1);

  $(trims).find(".trim.t1 .count").html(count1);
  $(trims).find(".trim.t2 .count").html(count2);
  $(trims).find(".trim.t3 .count").html(count3);
  $(trims).find(".trim.t4 .count").html(count4);

}

function showHidden(classname) {
  $('.hiddenpart.'+classname).toggle();
  if ($('.filter.'+classname).css('height') ==  '210px') {
    $('.filter.'+classname).css('height', '50px');
    $('.hiddenpart.'+classname).css('overflow-y', 'auto');
  } else {
    $('.filter.'+classname).css('height', '210px');
    $('.hiddenpart.'+classname).css('overflow-y', 'scroll');
  }
}

function showHiddenPart(classname) {
  if ($('div.popup .hiddenpart_pop.'+classname).is(':hidden')) {
    $('div.popup .hiddenpart_pop').hide();
    $('div.popup .hiddenpart_pop.'+classname).show();
  }
  else {
    $('div.popup .hiddenpart_pop.'+classname).hide();
  }
}

function closePop() {
  $('div.ekran').css('display', 'none');
  $('div.popup').css('display', 'none');
}
function showPop() {
  $('div.ekran').css('display', 'flex');
  $('div.popup').css('display', 'block');
}

// function fillPop(mark) {
function fillPop(name, address) {
  $('#nametek').html(name);
  $('#address').html(address);
  // климат
  fillStrokeWithTemperature();
}

function fillStrokeWithTemperature() {
  let insert = "";
  let po_datam = [];
  let date;
  let date_forhtml;
  let middle = 0, count = 0;
  for (var i = 0; i < climat.length; i++) {
    let date_this = climat[i].datetime;
    if (date != undefined) {
      if (date_this.split(" ")[0] == date[0]) {
        middle += parseInt(climat[i].temperature);
        count++;
      } else {
        insert += createSpanElement(date, middle/count, date_forhtml);

        date = date_this.split(" ");
        date_arr = date[0].split("-");
        date_forhtml = date_arr[2]+"."+date_arr[1]+"."+date_arr[0];

        middle += parseInt(climat[i].temperature);
        count++;
      }
    } else {
      date = date_this.split(" ");
      date_arr = date[0].split("-");
      date_forhtml = date_arr[2]+"."+date_arr[1]+"."+date_arr[0];
      middle += parseInt(climat[i].temperature);
      count++;
    }
  }

  $('#temps').html(insert);
}

function createSpanElement(date, middleT, date_html) {

  let date2 = "'"+date+"'";
  let span = '<div class="day" onclick="showMoreDegrees(this, '+date2+')">' +
    '<span class="degree">'+Math.floor(middleT)+'<sup><i class="fas fa-genderless"></i></sup>C</span>'+
    '<br>' +
    '<span class="icon-weather"><i class="fas fa-cloud-moon"></i></span>' +
    '<br><span class="date">'+date_html+'</span><br></div>';
  return span;
}

function sortDates() {
  let month = $('select[name=month]').val();
  let year = $('select[name=year]').val();
  $('div#temps span.center').remove();
  if (month == 'all' && year == 'all') {
    $('div.day').show();
  } else {
    let html = month+".20"+year;

    let count = 0;
    console.log(html);

    let divs = $('div.day');
    console.log(divs);
    for (var i = 0; i < divs.length; i++) {
      let date_html = $(divs[i]).find(".date").html();
      console.log(date_html);
      console.log(html);
      if (!date_html.includes(html)) {
        console.log('no');
        $(divs[i]).css('display', 'none');
        count++;
      } else {
        $(divs[i]).show('display', 'inline-block');
      }
    }

    checkDates(count);
  }
}

function checkDates(count) {
  if (count == $('div.day').length) {
    $('div#temps').html("<span class='center'>Нет данных.</span>")
  }
}

function showMoreDegrees(elem, date) {
  $(elem).addClass("select");

  let insert = "";
  for (var i = 0; i < climat.length; i++) {
    if (climat[i].datetime.includes(date[0])) {

      let time = climat[i].datetime.split(" ")[1];
      time = time.split(":");
      console.log(time);
      time2 = time[0]+":"+time[1];


      insert+=createSpanElement2(climat[i].temperature, time2);
    }
  }

  $('div#temps2').html(insert);
    $('div#temps2').css('display', 'flex');
}

function createSpanElement2(middleT, date_html) {

  let span = '<div class="day">' +
    '<span class="degree">'+Math.floor(middleT)+'<sup><i class="fas fa-genderless"></i></sup>C</span>'+
    '<br>' +
    '<span class="icon-weather"><i class="fas fa-cloud-moon"></i></span>' +
    '<br><span class="date">'+date_html+'</span><br></div>';
  return span;
}
